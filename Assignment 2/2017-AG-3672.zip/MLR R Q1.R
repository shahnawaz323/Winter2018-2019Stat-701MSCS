#faryal farooq 2017-ag-3672

#Multiple Linear Regression

# dependent Variable
yield_bushed <- c(40, 50, 50, 70, 65, 65, 80)

# Independent  Variables
rainfall_inches <- c(10, 20, 10, 30, 20, 20, 30)
fert_pound <- c(100, 200, 300, 400, 500, 600, 700)


# Creating Multiple Linear Regression Equation
Regression <- lm(yield_bushed ~ rainfall_inches + fert_pound)

#Show the results
summary(Regression)
plot(Regression)