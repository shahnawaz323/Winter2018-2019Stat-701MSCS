#faryal farooq 2017-ag-3672

#Multiple Linear Regression

# dependent Variable
DISK_Y<- c(40, 60, 60, 80, 65, 65, 90)

# Independent  Variables
DISK_X1<- c(10, 20, 10, 30, 20, 20, 30)
DISK_X2<- c(400, 500, 600, 700, 800, 900, 900)


# Creating Multiple Linear Regression Equation
Regression <- lm(DISK_Y ~ DISK_X1 + DISK_X2)

#Show the results
summary(Regression)
plot(Regression)