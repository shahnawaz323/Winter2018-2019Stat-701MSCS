#faryal farooq 2017-ag-3672

#Multiple Linear Regression

# dependent Variable
Y<- c(5,7,15,17,9,11)

# Independent  Variables
X1 <- c(0,0,10,10,20,20)
X2 <- c(0,0,100,100,400,400)


# Creating Multiple Linear Regression Equation
Regression1 <- lm(Y ~ X1 + X2)

#Show the results
summary(Regression1)
plot(Regression1)
