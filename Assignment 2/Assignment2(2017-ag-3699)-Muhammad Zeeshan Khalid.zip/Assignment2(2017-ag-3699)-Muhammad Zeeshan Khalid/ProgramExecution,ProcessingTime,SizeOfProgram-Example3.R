install.packages("scatterplot3d") 
library("scatterplot3d") 


Processing_Time = c(0,70,105,100,205,200)   
Size_of_program= c(0,0,100,100,400,400)  
Program_Execution = c(500,700,150,175,980,180) 

df = data.frame(Processing_Time,Size_of_program,Program_Execution)


data(df)
head(df)
scatterplot3d(x=Processing_Time, y=Size_of_program, z=Program_Execution)
s3d <- scatterplot3d(df, type = "p", color = "blue",
    angle=55, pch =16,grid=TRUE, box=FALSE,


              main="Multiple Linear Regression",
              xlab = "X1",
              ylab = "X2",
              zlab = "Y")

my.lm <- lm(Program_Execution~Processing_Time+Size_of_program)

s3d$plane3d(my.lm, lty.box = "solid",  draw_polygon = TRUE)

MLR<- function( X1, X2, Y )
{

	
	n = length(Y)

	
	mean.X1 = mean(X1)
	mean.X2 = mean(X2)
	mean.Y = mean(Y)

	
	x1 = X1 - mean.X1
	x2 = X2 - mean.X2
	y = Y - mean.Y
	
	
	Sum_x1 = sum(x1)
	Sum_x2 = sum(x2)
	Sum_y = sum(y)

	
	x1_square = sum((x1)^2)
	x2_square = sum((x2)^2)
	y_square = sum((y)^2)

	
	Sum_x1y = sum((x1*y))
	Sum_x1_square = sum((x1)^2)
	Sum_x2_square = sum((x2)^2)
	Sum_x2y = sum((x2*y))
	Sum_x1x2 = sum((x1*x2))

	Sum_x1y_Sum_x2_square = Sum_x1y*Sum_x2_square
	Sum_x2y_Sum_x1x2 = Sum_x2y*Sum_x1x2
	Sum_x1_square_Sum_x2_square = Sum_x1_square*Sum_x2_square
	Sum_x1x2_square = (Sum_x1x2)^2

	Beta1 = (Sum_x1y_Sum_x2_square - Sum_x2y_Sum_x1x2) / (Sum_x1_square_Sum_x2_square - Sum_x1x2_square)

	Beta2 = ((Sum_x2y*Sum_x1_square) - (Sum_x1y*Sum_x1x2)) / (Sum_x1_square_Sum_x2_square - Sum_x1x2_square)

	Beta0 = mean.Y - (Beta1*mean.X1) - (Beta2*mean.X2)

	
	k = 3	

	
	Y_hat = Beta0 + Beta1*Processing_Time + Beta2*Size_of_program
	Sum_Y_hat = sum(Beta0 + Beta1*Processing_Time + Beta2*Size_of_program)

	TSS = sum((Y - mean.Y)^2)
	MSS = sum((Y_hat - mean.Y)^2)
	RSS = sum((Y - Y_hat)^2)

	R_square = MSS / TSS

	
	MSE = RSS / (n - k)

	
	V_Beta1 = MSE*((Sum_x2_square) / (Sum_x1_square_Sum_x2_square - Sum_x1x2_square))
	SE_Beta1 = sqrt(V_Beta1)

	
	V_Beta2 = MSE*((Sum_x1_square) / (Sum_x1_square_Sum_x2_square - Sum_x1x2_square))
	SE_Beta2 = sqrt(V_Beta2)

	mean.X1_square = mean.X1^2
	mean.X2_square = mean.X2^2
	mean.X1_mean.X2 = mean.X1*mean.X2

	V_Beta0 = MSE*((1 / n) + ((mean.X1_square*Sum_x2_square + mean.X2_square*Sum_x1_square - 2*mean.X1_mean.X2*(Sum_x1x2)) / (Sum_x1_square_Sum_x2_square - Sum_x1x2_square)))
	SE_Beta0 = sqrt(V_Beta0)

	cat("Mean of X1 = ", mean.X1, "\n")
	cat("Mean of X2 = ", mean.X2, "\n")
	cat("Mean of Y = ", mean.Y, "\n")
	cat("\n")
	cat("Sum of Deviations of X1 = " ,Sum_x1, "\n")
	cat("Sum of Deviations of X2 = " ,Sum_x2, "\n")
	cat("Sum of Deviations of Y = " ,Sum_y, "\n")
	cat("\n")
	cat("Sum of Square of X1 : Sum_x1 = " ,x1_square, "\n")
	cat("Sum of Square of X2 : Sum_x2 = " ,x2_square, "\n")
	cat("Sum of Square of Y : Sum_y = " ,y_square, "\n")
	cat("\n")
	cat("Beta1  = " ,Beta1, "\n")
	cat("Beta2  = " ,Beta2, "\n")
	cat("Beta0  = " ,Beta0, "\n")
	cat("\n")
	cat("Sum of Y-hat = ", Sum_Y_hat , "\n")
	cat("\n")
	cat("Total Sum of Squares : TSS = ", TSS , "\n")
	cat("Model Sum of Squares : MSS = ", MSS , "\n")	
	cat("Residual Sum of Squares : RSS = ", RSS , "\n")
	cat("\n")
	cat("Regression Co-efficient : R^2 = ", R_square, "\n")
	cat("\n")
	cat("Mean Square Error : MSE = ",MSE,"\n")
	cat("\n")
	cat("Variance of Beta1 = ",V_Beta1, "\n")
	cat("Standard Error of Beta1 = ",SE_Beta1, "\n")
	cat("\n")
	cat("Variance of Beta2 = ",V_Beta2,"\n")
	cat("Standard Error of Beta2 = ",SE_Beta2, "\n")
	cat("\n")
	cat("Variance of Beta0 = ",V_Beta0,"\n")
	cat("Standard Error of Beta0 = ",SE_Beta0, "\n")

	df2 = data.frame(X1,X2,Y)

	fit <- lm(Y ~ X1 + X2, data=df2)
	summary(fit)

	}


Exp.data = cbind(Processing_Time, Size_of_program, Program_Execution)

colnames(Exp.data) = c('Processing_Time' , 'Size_of_program' , 'Program_Execution')

Exp.data

Exp.regression<- MLR( Processing_Time, Size_of_program, Program_Execution)


Exp.regression