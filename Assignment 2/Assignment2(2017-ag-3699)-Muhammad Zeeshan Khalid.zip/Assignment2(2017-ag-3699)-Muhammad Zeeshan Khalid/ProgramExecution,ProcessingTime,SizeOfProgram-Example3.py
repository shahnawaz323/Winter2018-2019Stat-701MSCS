from mpl_toolkits.mplot3d import Axes3D
from matplotlib import pyplot as plt
import numpy as np
import pandas as pd
import math as math
from statsmodels.formula.api import ols
from statsmodels.stats.anova import anova_lm

Program_Execution = np.array([76, 349, 143, 175, 700, 180, 589])
Processing_Time = np.array([100, 570, 15, 104, 205, 200, 344])
Size_of_program = np.array([329, 456, 100, 10, 400, 560, 678])

n = Program_Execution.size
print("\nNumber of Observations : n = ",n)

Program_Execution_mean = sum(Program_Execution)/Program_Execution.size
Processing_Time_mean = sum(Processing_Time)/Processing_Time.size
Size_of_program_mean = sum(Size_of_program)/Size_of_program.size

print("\nMean for Data transfer rate = ",Program_Execution_mean)
print("Mean for number of signals = ",Processing_Time_mean)
print("Mean for number of nodes = ",Size_of_program_mean)

x1 = Processing_Time - Processing_Time_mean
x2 = Size_of_program - Size_of_program_mean
y = Program_Execution - Program_Execution_mean

print("\nx1 =",x1)
print("x2 =",x2)
print("Y =",y)

Σx1 = np.sum(x1)
Σx2 = np.sum(x2)
Σy = np.sum(y)

x1_square = np.sum((x1)**2)
x2_square = np.sum((x2)**2)
y_square = np.sum((y)**2)

Σx1y = np.sum((x1*y))
Σx1_square = np.sum((x1)**2)
Σx2_square = np.sum((x2)**2)
Σx2y = np.sum((x2*y))
Σx1x2 = np.sum((x1*x2))

Σx1y_Σx2_square = Σx1y*Σx2_square
Σx2y_Σx1x2 = Σx2y*Σx1x2
Σx1_square_Σx2_square = Σx1_square*Σx2_square
Σx1x2_square = (Σx1x2)**2

Beta1 = (Σx1y_Σx2_square - Σx2y_Σx1x2) / (Σx1_square_Σx2_square - Σx1x2_square)
print("\nBeta1 = ",Beta1)

Beta2 = ( (Σx2y*Σx1_square) - (Σx1y*Σx1x2) ) / (Σx1_square_Σx2_square - Σx1x2_square)
print("Beta2 = ",Beta2)

Beta0 = Program_Execution_mean - (Beta1*Processing_Time_mean) - (Beta2*Size_of_program_mean)
print("Beta0 = ",Beta0)

k = 3
print("\nNumber of Parameters B0, B1, B2 : k = ",k)

Y_hat = Beta0 + Beta1*Processing_Time + Beta2*Size_of_program


print("\nY_hat = {} + {}X1 + {}X2".format(Beta0,Beta1,Beta2))

TSS = np.sum((Program_Execution - Program_Execution_mean)**2)
MSS = np.sum((Y_hat - Program_Execution_mean)**2)
RSS = np.sum((Program_Execution - Y_hat)**2)

print("\nTotal Sum of Squares : TSS = ",TSS)
print("Model Sum of Squares : MSS = ",MSS)
print("Residual Sum of Squares : RSS = ",RSS)

R_square = MSS/TSS
print("\nR_square = ",R_square)

MSE = RSS/(n-k)
print("\nMeans Square Error : MSE = ",MSE)

V_Beta1 = MSE *( (Σx2_square) / (Σx1_square_Σx2_square - Σx1x2_square) )
SE_Beta1 = math.sqrt(V_Beta1)
print("\nVariance of Beta1 = ",V_Beta1)
print("Standard Error of Beta1 : SE(Beta1) = ",SE_Beta1)

V_Beta2 = MSE *( (Σx1_square) / (Σx1_square_Σx2_square - Σx1x2_square) )
SE_Beta2 = math.sqrt(V_Beta2)
print("\nVariance of Beta2 = ",V_Beta2)
print("Standard Error of Beta2 : SE(Beta2) = ",SE_Beta2)

Processing_Time_mean_square = Processing_Time_mean**2
Size_of_program_mean_square = Size_of_program_mean**2
Processing_Time_mean_Size_of_program_mean = Processing_Time_mean*Size_of_program_mean

V_Beta0 = MSE * ((1/n) + ((Processing_Time_mean_square*Σx2_square + Size_of_program_mean_square*Σx1_square - 2*Processing_Time_mean_Size_of_program_mean*(Σx1x2))/(Σx1_square_Σx2_square - Σx1x2_square)))
SE_Beta0 = math.sqrt(V_Beta0)
print("\nVariance of Beta0 = ",V_Beta0)
print("Standard Error of Beta0 : SE(Beta0) = ",SE_Beta0)

data_frame = pd.DataFrame(
    {
        "Y": Program_Execution
        , "X1": Processing_Time
        , "X2": Size_of_program
    }
)

Reg = ols(formula="Program_Execution ~ Processing_Time + Size_of_program", data=data_frame)
Fit2 = Reg.fit()
print("\n", Fit2.summary())
print("\n", anova_lm(Fit2))




fig = plt.figure()
ax = fig.add_subplot(111, projection="3d")
ax.scatter(
    data_frame["X1"]
    , data_frame["X2"]
    , data_frame["Y"]
    , color="green"
    , marker="o"
    , alpha=1
)
ax.set_xlabel("X1")
ax.set_ylabel("X2")
ax.set_zlabel("Y")

plt.show()




